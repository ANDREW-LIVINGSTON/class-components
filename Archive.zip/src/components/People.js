import React, {Component} from 'react';

class People extends Component{
    render(){
        
        const { name, age, color } = this.props;
        return <div className="person">
            <h1>{name}</h1>
            <p>Age: {age}</p>
            <p>Hair Color: {color}</p>
        </div>
    }
}

export default People;